<?php

require_once "autoload.php";

$cartera = new Lighting();
$cartera->importLamps("lighting.csv");

?>