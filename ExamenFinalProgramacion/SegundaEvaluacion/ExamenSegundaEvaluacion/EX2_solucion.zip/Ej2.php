<?php
require_once "autoload.php";

$surveillance = new Surveillance("data.csv", false);
if(count($_POST)>0) $surveillance->update($_POST["camera"]);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <select name="camera">
            <?= $surveillance->drawSelect() ?>
        </select>
        <input type="submit" value="Initialize">
    </form>
    <?php var_dump($surveillance) ?>
</body>

</html>