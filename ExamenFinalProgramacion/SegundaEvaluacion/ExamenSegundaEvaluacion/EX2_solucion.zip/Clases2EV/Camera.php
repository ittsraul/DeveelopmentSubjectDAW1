<?php

class Camera
{
    private $id;
    private $latitude;
    private $longitude;
    private $checked;
    private $match;
    private $timeUp;

    public function __construct($id, $latitude, $longitude, $checked, $match, $timeUp)
    {
        $this->id = $id;
        $this->latitude = $latitude;
        $this->longitude = $longitude;
        $this->checked = $checked;
        $this->match = $match;
        $this->setTimeUp($timeUp);
    }
    public function setTimeUp($timeUp)
    {
        $this->timeUp = round((time() - strtotime($timeUp)) / (60 * 60 * 24),0,PHP_ROUND_HALF_UP);
    }

    public function getEfficiency(){
        return $this->getMatch() / ($this->getChecked() * $this->getTimeUp());
    }

    public function getId()
    {
        return $this->id;
    }

    public function getChecked()
    {
        return $this->checked;
    }

    public function getMatch()
    {
        return $this->match;
    }

    public function getTimeUp()
    {
        return $this->timeUp;
    }

    public function setChecked($checked)
    {
        $this->checked = $checked;

        return $this;
    }

    public function setMatch($match)
    {
        $this->match = $match;

        return $this;
    }
}
