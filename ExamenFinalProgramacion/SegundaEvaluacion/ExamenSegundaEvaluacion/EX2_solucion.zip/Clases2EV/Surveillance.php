<?php

class Surveillance
{
    private $cameras = [];
    private $active;

    public function __construct($cameras, $active)
    {
        $this->active = $active;
        $this->createCameras($cameras);
    }

    private function createCameras($fichero)
    {
        $gestor = fopen($fichero, "r");
        while (($camera = fgetcsv($gestor)) !== false) {
            $active = $camera[5] == 'true' ? true : false;
            if ($active === $this->active) {
                array_push($this->cameras, new Camera(
                    $camera[0],
                    $camera[1],
                    $camera[2],
                    $camera[3],
                    $camera[4],
                    $camera[6],
                ));
            }
        }
        fclose($gestor);
    }

    public function getCamera($id)
    {
        foreach ($this->cameras as $camera) {
            if ($camera->getId() == $id) return $camera;
        }
    }

    public function setCamera($id, $lat, $lon)
    {
        array_push($this->cameras, new Camera($id, $lat, $lon, 0, 0, date("d-m-Y", time())));
    }

    public function compareCameras($idCam1, $idCam2)
    {
        $cam1 = $this->getCamera($idCam1);
        $cam2 = $this->getCamera($idCam2);

        return ($cam1->getEfficiency() > $cam2->getEfficiency()) ? $cam1 : $cam2;
    }

    public function averageEfficiency()
    {
        $total = 0;
        foreach ($this->cameras as $camera) {
            $total += $camera->getEfficiency();
        }
        return $total / count($this->cameras);
    }

    public function drawSelect()
    {
        $output = "";
        foreach ($this->cameras as $camera) {
            $output .= "<option value='" . $camera->getId() . "'>" . $camera->getId() . "</option>";
        }
        return $output;
    }

    public function update($id)
    {
        $camera = $this->getCamera($id);
        $camera->setChecked(0);
        $camera->setMatch(0);
        $camera->setTimeUp(date("d-m-Y", time()));
    }
}
