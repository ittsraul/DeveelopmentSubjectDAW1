<?php

require_once "autoload.php";

$surveillance = new Surveillance("data.csv", true);
var_dump($surveillance);

var_dump($surveillance->getCamera("Y5V6"));
var_dump($surveillance->compareCameras("H8I3", "Y5V6"));

echo $surveillance->averageEfficiency();

$surveillance->setCamera("A1B2", 40, 1);
var_dump($surveillance);
