<?php

/*
Ejercicio 10.- Conecta y obtén el listado de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria". Este listado deberá mostrar el nombre del cliente, sú código de cliente y el teléfono en una tabla. Muestra solo los 5 primeros, ordenados por nombre de forma descendente.
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT NombreCliente, CodigoCliente, Telefono FROM Clientes ORDER BY NombreCliente DESC LIMIT 5";
$result = $conn->query($sql);


if ($result->rowCount() > 0) {
  echo "<table border='1'>";
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>". $row["CodigoCliente"]. "</td>";
    echo "<td>". $row["NombreCliente"]. "</td>";
    echo "<td>". $row["Telefono"]. "</td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}

//cierra la conexión
$conn = null;