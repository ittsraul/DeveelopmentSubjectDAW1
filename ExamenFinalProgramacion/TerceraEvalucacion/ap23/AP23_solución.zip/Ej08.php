<?php

/*
Ejercicio 8.- Conecta y obtén el listado de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria". Este listado deberá mostrar el nombre del cliente, sú código de cliente y el teléfono en cada línea, separando los campos por comas
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT NombreCliente, CodigoCliente, Telefono FROM Clientes";
$result = $conn->query($sql);

if ($result->rowCount() > 0) {
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
    echo $row["CodigoCliente"]. "," . $row["NombreCliente"]. "," . $row["Telefono"]. "<br>";
  }
} else {
  echo "0 results";
}

//cierra la conexión
$conn = null;