<?php

/*
Ejercicio 3.- Conecta y obtén el total de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria" cuya ciudad es "Madrid".
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT * FROM Clientes WHERE Ciudad = 'Madrid'";
$result = $conn->query($sql);

echo "La base de datos tiene " . $result->rowCount() . " clientes de Madrid";

//cierra la conexión
$conn = null;
