<?php

/*
Ejercicio 6.- Conecta y obtén el total de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria" cuyo límite de crédito es mayor al parámetro pasado por URL llamado "limite".
 */

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT * FROM Clientes WHERE LimiteCredito > " . $_GET["limite"];
$result = $conn->query($sql);

if ($result->rowCount() > 0) {
    echo "La base de datos tiene " . $result->rowCount() . " clientes con límite de crédito mayor a " . $_GET["limite"] . "€";
}

//cierra la conexión
$conn = null;