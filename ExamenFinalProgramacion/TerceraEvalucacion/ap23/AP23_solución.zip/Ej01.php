<?php

/*
Ejercicio 1.- descarga el fichero "jardineria.sql" e importalo a tu servidor MySql. Crea el código necesario para conectar con la base de datos.
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db",$username, $password);

//cierra la conexión
$conn=null;