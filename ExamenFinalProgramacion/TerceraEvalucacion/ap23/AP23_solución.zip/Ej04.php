<?php

/*
Ejercicio 4.- Conecta y obtén el total de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria" cuyo límite de crédito es mayor de 20.000.
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT * FROM Clientes WHERE LimiteCredito > 20000";
$result = $conn->query($sql);

if ($result->rowCount() > 0) echo "La base de datos tiene " . $result->rowCount() . " clientes con límite de crédito mayor a 20.000€";

//cierra la conexión
$conn = null;
