<?php

/*
Ejercicio 9.- Conecta y obtén el listado de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria". Este listado deberá mostrar el nombre del cliente, sú código de cliente y el teléfono en cada línea, separando los campos por comas. Muestra solo los 10 primeros, ordenados por nombre de forma ascendente.
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT NombreCliente, CodigoCliente, Telefono FROM Clientes ORDER BY NombreCliente ASC LIMIT 10";
$result = $conn->query($sql);

if ($result->rowCount() > 0) {
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
    echo $row["CodigoCliente"]. "," . $row["NombreCliente"]. "," . $row["Telefono"]. "<br>";
  }
} else {
  echo "0 results";
}

//cierra la conexión
$conn = null;