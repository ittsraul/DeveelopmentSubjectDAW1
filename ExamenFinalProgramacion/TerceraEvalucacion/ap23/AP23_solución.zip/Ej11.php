<?php

/*
Ejercicio 11.- Conecta y obtén toda la información del cliente con código 10. Muestralo en una tabla, cada dato en una fila, añadiendo el nombre del campo en una celda, y su valor en la celda siguiente.
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT CodigoCliente,NombreCliente,NombreContacto,ApellidoContacto,Telefono,Fax,LineaDireccion1,LineaDireccion2,Ciudad,Region,Pais,CodigoPostal,CodigoEmpleadoRepVentas,LimiteCredito FROM Clientes WHERE CodigoCliente = 10";
$result = $conn->query($sql);


if ($result->rowCount() > 0) {
  echo "<table border='1'>";
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr><td>CodigoCliente</td><td>". $row["CodigoCliente"]. "</td></tr>";
    echo "<tr><td>NombreCliente</td><td>". $row["NombreCliente"]. "</td></tr>";
    echo "<tr><td>NombreContacto</td><td>". $row["NombreContacto"]. "</td></tr>";
    echo "<tr><td>ApellidoContacto</td><td>". $row["ApellidoContacto"]. "</td></tr>";
    echo "<tr><td>Telefono</td><td>". $row["Telefono"]. "</td></tr>";
    echo "<tr><td>Fax</td><td>". $row["Fax"]. "</td></tr>";
    echo "<tr><td>LineaDireccion1</td><td>". $row["LineaDireccion1"]. "</td></tr>";
    echo "<tr><td>LineaDireccion2</td><td>". $row["LineaDireccion2"]. "</td></tr>";
    echo "<tr><td>Ciudad</td><td>". $row["Ciudad"]. "</td></tr>";
    echo "<tr><td>Region</td><td>". $row["Region"]. "</td></tr>";
    echo "<tr><td>Pais</td><td>". $row["Pais"]. "</td></tr>";
    echo "<tr><td>CodigoPostal</td><td>". $row["CodigoPostal"]. "</td></tr>";
    echo "<tr><td>CodigoEmpleadoRepVentas</td><td>". $row["CodigoEmpleadoRepVentas"]. "</td></tr>";
    echo "<td>LimiteCredito</td><td>". $row["LimiteCredito"]. "</td></tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}

//cierra la conexión
$conn = null;