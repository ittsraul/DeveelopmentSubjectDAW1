<?php

/*
Ejercicio 2.- Conecta y obtén el total de clientes que hay registrados en la tabla "clientes" de la base de datos "jardineria".
*/

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
$sql = "SELECT COUNT(*) AS numClientes FROM Clientes";
$result = $conn->query($sql);
$total = $result->fetch(PDO::FETCH_ASSOC);

echo "La base de datos tiene " . $total["numClientes"] . " clientes";

//cierra la conexión
$conn = null;
