<?php


$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

try {
    //Establece la conexión
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->beginTransaction();

    $stmt = $conn->prepare("SELECT CodigoEmpleado FROM empleados WHERE Nombre = ? AND Apellido1 = ? AND Apellido2 = ?");

    $stmt->bindParam(1, $JefeNombre, PDO::PARAM_STR);
    $stmt->bindParam(2, $JefeApellido1, PDO::PARAM_STR);
    $stmt->bindParam(3, $JefeApellido2, PDO::PARAM_STR);

    $JefeNombre = "Alberto";
    $JefeApellido1 = "Soria";
    $JefeApellido2 = "Carrasco";
    
    $stmt->execute();
    $jefeAntiguo = $stmt->fetch(PDO::FETCH_ASSOC)["CodigoEmpleado"];

    $JefeNombre = "José Manuel";
    $JefeApellido1 = "Martinez";
    $JefeApellido2 = "De la Osa";

    $stmt->execute();
    $jefeNuevo = $stmt->fetch(PDO::FETCH_ASSOC)["CodigoEmpleado"];
    
    echo "$jefeAntiguo - $jefeNuevo";

    $stmtUpdate = $conn->prepare("UPDATE empleados SET CodigoJefe = ? WHERE CodigoJefe = ?");

    $stmtUpdate->bindParam(1, $jefeNuevo, PDO::PARAM_INT);
    $stmtUpdate->bindParam(2, $jefeAntiguo, PDO::PARAM_INT);

    $stmtUpdate->execute();
    $stmtUpdate->debugDumpParams();
    $conn->commit();

} catch (PDOException $e) {
    echo "<br>Se ha producido una excepción:" . $e->getMessage();
} finally {
    //cierra la conexión
    $conn = null;
}
