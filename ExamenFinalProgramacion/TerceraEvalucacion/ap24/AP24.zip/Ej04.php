<?php

if (count($_POST) > 0) {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $db = "jardineria";

    try {
        //Establece la conexión
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->beginTransaction();

        $CodigoEmpleado = $_POST["CodigoEmpleado"];
        $Nombre = $_POST["Nombre"];
        $Apellido1 = $_POST["Apellido1"];
        $Apellido2 = $_POST["Apellido2"];
        $Extension = $_POST["Extension"];
        $Email = $_POST["Email"];
        $CodigoOficina = $_POST["CodigoOficina"];
        $CodigoJefe = $_POST["CodigoJefe"];
        $Puesto = $_POST["Puesto"];

        //?CodigoEmpleado=1000&Nombre=David&Apellido1=Soler&Apellido2=Talens&Extension=24&Email=dsoler@florida-uni.es&CodigoOficina=BCN-ES&CodigoJefe=1&Puesto=Profesor

        $sql = "INSERT INTO `empleados`(`CodigoEmpleado`, `Nombre`, `Apellido1`, `Apellido2`, `Extension`, `Email`, `CodigoOficina`, `CodigoJefe`, `Puesto`) VALUES ($CodigoEmpleado,'$Nombre','$Apellido1','$Apellido2','$Extension','$Email','$CodigoOficina',$CodigoJefe,'$Puesto')";

        /* $stmt = $conn->prepare("SELECT * FROM empleados WHERE CodigoEmpleado = :cod");
        $stmt->bindParam(':cod',$cod, PDO::PARAM_INT);
        $cod = 1;
        $result = $stmt->execute(); */

        echo $sql;
        $filas = $conn->exec($sql);
        if ($filas != 0) {
            echo "Filas afectadas" . $filas;
            $conn->commit();
        } else {
            $conn->rollBack();
            throw new PDOException(implode(",", $conn->errorInfo()));
        }
    } catch (PDOException $e) {
        echo "<br>Se ha producido una excepción:" . $e->getMessage();
        /* } catch (ErrorException $e) {
    echo "do something..."; */
    } finally {
        //cierra la conexión
        $conn = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="POST">
        CodigoEmpleado<input type="text" name="CodigoEmpleado"><br>
        Nombre<input type="text" name="Nombre"><br>
        Apellido1<input type="text" name="Apellido1"><br>
        Apellido2<input type="text" name="Apellido2"><br>
        Extension<input type="text" name="Extension"><br>
        Email<input type="text" name="Email"><br>
        CodigoOficina<input type="text" name="CodigoOficina"><br>
        CodigoJefe<input type="text" name="CodigoJefe"><br>
        Puesto<input type="text" name="Puesto"><br>
        <input type="submit" value="Enviar">
    </form>
</body>

</html>