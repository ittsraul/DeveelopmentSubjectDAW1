<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

try {
    //Establece la conexión
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    $conn->beginTransaction();

    $CodigoEmpleado = $_GET["CodigoEmpleado"];
    $Nombre = $_GET["Nombre"];
    $Apellido1 = $_GET["Apellido1"];
    $Apellido2 = $_GET["Apellido2"];
    $Extension = $_GET["Extension"];
    $Email = $_GET["Email"];
    $CodigoOficina = $_GET["CodigoOficina"];
    $CodigoJefe = $_GET["CodigoJefe"];
    $Puesto = $_GET["Puesto"];

    //?CodigoEmpleado=1000&Nombre=David&Apellido1=Soler&Apellido2=Talens&Extension=24&Email=dsoler@florida-uni.es&CodigoOficina=BCN-ES&CodigoJefe=1&Puesto=Profesor

    $sql = "INSERT INTO `empleadoss`(`CodigoEmpleado`, `Nombre`, `Apellido1`, `Apellido2`, `Extension`, `Email`, `CodigoOficina`, `CodigoJefe`, `Puesto`) VALUES ($CodigoEmpleado,'$Nombre','$Apellido1','$Apellido2','$Extension','$Email','$CodigoOficina',$CodigoJefe,'$Puesto')";

    echo $sql;
    $filas = $conn->exec($sql);
    if ($filas != 0) {
        echo "Filas afectadas" . $filas;
        $conn->commit();
    } else {
        $conn->rollBack();
        throw new PDOException(implode(",", $conn->errorInfo()));
    }
} catch (PDOException $e) {
    echo "<br>Se ha producido una excepción:" . $e->getMessage();
/* } catch (ErrorException $e) {
    echo "do something..."; */
} finally {
    //cierra la conexión
    $conn = null;
}
