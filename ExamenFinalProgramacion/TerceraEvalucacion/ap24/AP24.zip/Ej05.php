<?php

if (count($_POST) > 0) {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $db = "jardineria";

    try {
        //Establece la conexión
        $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->beginTransaction();

        $CodigoEmpleado = $_POST["CodigoEmpleado"];
        $Nombre = $_POST["Nombre"];
        $Apellido1 = $_POST["Apellido1"];
        $Apellido2 = $_POST["Apellido2"];
        $Extension = $_POST["Extension"];
        $Email = $_POST["Email"];
        $CodigoOficina = $_POST["CodigoOficina"];
        $CodigoJefe = $_POST["CodigoJefe"];
        $Puesto = $_POST["Puesto"];

        $stmt = $conn->prepare("INSERT INTO `empleados`(`CodigoEmpleado`, `Nombre`, `Apellido1`, `Apellido2`, `Extension`, `Email`, `CodigoOficina`, `CodigoJefe`, `Puesto`) VALUES (:CodigoEmpleado,:Nombre,:Apellido1,:Apellido2,:Extension,:Email,:CodigoOficina,:CodigoJefe,:Puesto)");

        $stmt->bindParam(':CodigoEmpleado', $CodigoEmpleado, PDO::PARAM_INT);
        $stmt->bindParam(':Nombre', $Nombre, PDO::PARAM_STR);
        $stmt->bindParam(':Apellido1', $Apellido1, PDO::PARAM_STR);
        $stmt->bindParam(':Apellido2', $Apellido2, PDO::PARAM_STR);
        $stmt->bindParam(':Extension', $Extension, PDO::PARAM_STR);
        $stmt->bindParam(':Email', $Email, PDO::PARAM_STR);
        $stmt->bindParam(':CodigoOficina', $CodigoOficina, PDO::PARAM_STR);
        $stmt->bindParam(':CodigoJefe', $CodigoJefe, PDO::PARAM_INT);
        $stmt->bindParam(':Puesto', $Puesto, PDO::PARAM_STR);

        $stmt->execute();
        echo "Insert realizado con éxito";
        $conn->commit();

    } catch (PDOException $e) {
        echo "<br>Se ha producido una excepción:" . $e->getMessage();
    } finally {
        //cierra la conexión
        $conn = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="POST">
        CodigoEmpleado<input type="text" name="CodigoEmpleado"><br>
        Nombre<input type="text" name="Nombre"><br>
        Apellido1<input type="text" name="Apellido1"><br>
        Apellido2<input type="text" name="Apellido2"><br>
        Extension<input type="text" name="Extension"><br>
        Email<input type="text" name="Email"><br>
        CodigoOficina<input type="text" name="CodigoOficina"><br>
        CodigoJefe<input type="text" name="CodigoJefe"><br>
        Puesto<input type="text" name="Puesto"><br>
        <input type="submit" value="Enviar">
    </form>
</body>

</html>