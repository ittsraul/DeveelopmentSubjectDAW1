<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db",$username, $password);

$sql="INSERT INTO `empleados`(`CodigoEmpleado`, `Nombre`, `Apellido1`, `Apellido2`, `Extension`, `Email`, `CodigoOficina`, `CodigoJefe`, `Puesto`) VALUES (999,'David','Soler','Talens','24','dsoler@florida-uni.es','BCN-ES',1,'Profesor')";

echo "Filas afectadas" . $conn->exec($sql);

//cierra la conexión
$conn=null;