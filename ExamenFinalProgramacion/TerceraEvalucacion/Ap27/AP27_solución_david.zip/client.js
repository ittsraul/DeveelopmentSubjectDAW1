document.addEventListener("DOMContentLoaded", main);

function main() {
    loadData();
    document.getElementById("insertForm").addEventListener("submit", function (e) {
        e.preventDefault();
        newAction(this);
    });
    document.getElementById("updateForm").addEventListener("submit", function (e) {
        e.preventDefault();
        updateAction(this);
    });
    document.getElementById("newClientAction").addEventListener("click", function (e) {
        e.preventDefault();
        document.getElementById("insertForm").reset();
        showModal("clientNew");
    });
    let closeButtons = document.getElementsByClassName("closeButton");
    for (let index = 0; index < closeButtons.length; index++) {
        closeButtons[index].addEventListener("click", function (e){
            e.preventDefault();
            showModal(null);
        });
    }
}
function loadData() {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            let data = JSON.parse(this.responseText);
            drawList(data);
        }
    });
    xhttp.open("GET", "list.php", true);
    xhttp.send();
}
function loadClient(id) {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            let data = JSON.parse(this.responseText);
            let form = document.getElementById("updateForm");
            form.id.value = data["id"];
            form.investment.value = data["investment"];
            form.company.value = data["company"];
            form.date.value = data["date"];
            form.active.checked = data["active"];
            form.info.innerHTML = data["info"];
        }
    });
    xhttp.open("GET", "detail.php?id=" + id, true);
    xhttp.send();
}
function drawList(data) {
    let clientRows = document.getElementById("clientRows");
    clientRows.innerHTML = "";
    for (let index = 0; index < data.length; index++) {
        let row = document.createElement("tr");
        let id = data[index]["id"];
        for (field in data[index]) {
            let col = document.createElement("td");
            let currentValue = data[index][field];
            switch (field) {
                case "id":
                    col.innerHTML = id;
                    break;
                case "company":
                    let detailLink = document.createElement("a");
                    detailLink.innerHTML = currentValue;
                    detailLink.href = "";
                    detailLink.addEventListener("click", function (e) {
                        e.preventDefault();
                        detailAction(id);
                    });
                    col.appendChild(detailLink);
                    break;
                case "investment":
                    col.innerHTML = numberFormatter(currentValue);
                    break;
                case "date":
                    col.innerHTML = dateFormatter(currentValue);
                    break;
                case "active":
                    let activeIcon = document.createElement("img");
                    if (data[index]["active"]) {
                        activeIcon.src = "img/img05.gif";
                    } else {
                        activeIcon.src = "img/img06.gif";
                    }
                    col.appendChild(activeIcon);
                    break;
            }
            row.appendChild(col);

        }
        for (let i = 0; i < 2; i++) {
            let col = document.createElement("td");
            let icon = document.createElement("img");
            icon.style.width = "25px";
            icon.style.cursor = "pointer";
            if (i) {
                icon.src = "img/del_icon.png";
                icon.addEventListener("click", function () {
                    removeAction(id);
                });
            } else {
                icon.src = "img/edit_icon.png";
                icon.addEventListener("click", function () {
                    loadClient(id);
                    showModal("clientUpdate");
                });
            }
            col.appendChild(icon);
            row.appendChild(col);
        }
        clientRows.appendChild(row);
    }
}
function showModal(modal) {
    document.getElementById("clientNew").style.display = "none";
    document.getElementById("clientDetail").style.display = "none";
    document.getElementById("clientUpdate").style.display = "none";
    if (modal != null) document.getElementById(modal).style.display = "grid";
}
function drawDetail(data) {
    showModal("clientDetail");
    let clientData = document.getElementById("clientData");
    clientData.innerHTML = "";

    for (field in data) {
        let row = document.createElement("tr");
        let th = document.createElement("th");
        th.innerHTML = field.charAt(0).toUpperCase() + field.slice(1);
        let td = document.createElement("td");
        switch (field) {
            case "investment":
                td.innerHTML = numberFormatter(data[field]);
                break;
            case "date":
                td.innerHTML = dateFormatter(data[field]);
                break;
            case "active":
                let activeIcon = document.createElement("img");
                if (data["active"]) {
                    activeIcon.src = "img/img05.gif";
                } else {
                    activeIcon.src = "img/img06.gif";
                }
                td.appendChild(activeIcon);
                break;
            default:
                td.innerHTML = data[field];
        }
        row.appendChild(th);
        row.appendChild(td);
        clientData.appendChild(row);
    }

}
function detailAction(id) {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            let data = JSON.parse(this.responseText);
            drawDetail(data);
        }
    });
    xhttp.open("GET", "detail.php?id=" + id, true);
    xhttp.send();
}
function newAction(form) {
    let newForm = new FormData(form);
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            loadData();
        }
    });
    xhttp.open("POST", "new.php", true);
    xhttp.send(newForm);
}
function removeAction(id) {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            loadData();
        }
    });
    xhttp.open("GET", "delete.php?id=" + id, true);
    xhttp.send();
}
function updateAction(form) {
    let updateForm = new FormData(form);
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            loadData();
        }
    });
    xhttp.open("POST", "update.php", true);
    xhttp.send(updateForm);
}
function numberFormatter(num) {
    let formattedNumber = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(num);
    return formattedNumber.replace(",", "'");
}
function dateFormatter(originDate) {
    let dateObject = new Date(originDate);
    return dateObject.getDate().toString().padStart(2, "0") + "/"
        + (dateObject.getMonth() + 1).toString().padStart(2, "0") + "/"
        + dateObject.getFullYear();
}
