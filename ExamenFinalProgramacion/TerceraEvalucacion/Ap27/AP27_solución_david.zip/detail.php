<?php

require_once "autoload.php";

$cartera = new Cartera();
echo json_encode($cartera->getClient($_GET["id"]));
