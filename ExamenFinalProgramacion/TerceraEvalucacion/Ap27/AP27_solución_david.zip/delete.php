<?php
require_once "autoload.php";

$cartera = new Cartera();
$cartera->delete($_GET["id"]);
