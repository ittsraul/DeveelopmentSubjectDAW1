<?php
require_once "autoload.php";

$cartera = new Cartera();
if (count($_POST) > 0) $cartera->update($_POST);


