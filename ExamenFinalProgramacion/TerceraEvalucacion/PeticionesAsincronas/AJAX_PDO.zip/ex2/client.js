document.addEventListener("DOMContentLoaded", main);

function main() {
    document.getElementById("loader").addEventListener("click", function () {
        const xhttp = new XMLHttpRequest();
        xhttp.addEventListener("readystatechange", function () {
            if (this.readyState == 4 && this.status == 200) {
                //console.log(this.responseText);
                let data = JSON.parse(this.responseText);
                //console.log(data);
                draw(data);
            }
        });
        let codigo = document.getElementById("codigo").value;
        xhttp.open("GET", "json_output.php?codigo=" + codigo, true);
        xhttp.send();
    });
}

function draw(data) {
    let container = document.getElementById("container");
    container.innerHTML = "";
    let table = document.createElement("table");
    for (index in data) {
        let row = document.createElement("tr");

        let colLabel = document.createElement("td");
        colLabel.innerHTML = index;
        row.appendChild(colLabel);

        let colValue = document.createElement("td");
        colValue.innerHTML = data[index];
        row.appendChild(colValue);

        table.appendChild(row);
    }
    container.appendChild(table);
}