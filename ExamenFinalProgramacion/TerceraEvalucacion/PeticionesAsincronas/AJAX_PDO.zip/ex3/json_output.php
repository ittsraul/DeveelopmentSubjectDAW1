<?php


$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

try {
    //Establece la conexión
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if (count($_POST) > 0) {
        $conn->beginTransaction();

        $stmt = $conn->prepare("DELETE FROM Empleados WHERE CodigoEmpleado = ?");
        $stmt->bindParam(1, $_POST["CodigoEmpleado"], PDO::PARAM_INT);

        $stmt->execute();
        $conn->commit();
    }

    $sql = "SELECT CodigoEmpleado, Nombre, Apellido1, Apellido2 FROM Empleados ORDER BY Apellido1, Apellido2, Nombre";

    $empleadosDB = $conn->query($sql);
    $empleados = $empleadosDB->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($empleados);
    
} catch (PDOException $e) {
    echo "<br>Se ha producido una excepción:" . $e->getMessage();
} finally {
    //cierra la conexión
    $conn = null;
}