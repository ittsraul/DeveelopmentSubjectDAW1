document.addEventListener("DOMContentLoaded", main);

function main() {
    let formElement = document.getElementById("deleteForm");
    loadData(formElement);
    formElement.addEventListener("submit", function (e) {
        e.preventDefault();
        loadData(this);
    });
}

function loadData(elem) {
    let deleteForm = new FormData(elem);
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            //console.log(this.responseText);
            let data = JSON.parse(this.responseText);
            //console.log(data);
            updateOptions(data);
        }
    });
    xhttp.open("POST", "json_output.php", true);
    xhttp.send(deleteForm);
}

function updateOptions(data) {
    let empOptionList = document.getElementById("CodigoEmpleado");
    empOptionList.innerHTML = "";
    for (index = 0; index < data.length; index++) {
        let option = document.createElement("option");
        option.innerHTML = data[index]["Apellido1"] + " " + data[index]["Apellido2"] + ", " + data[index]["Nombre"];
        option.value = data[index]["CodigoEmpleado"];
        empOptionList.appendChild(option);
    }
}