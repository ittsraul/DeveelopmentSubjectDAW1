document.addEventListener("DOMContentLoaded", main);

function main() {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            let data = JSON.parse(this.responseText);
            updateOptions(data);
        }
    });
    xhttp.open("GET", "json_output.php", true);
    xhttp.send();

    document.getElementById("deleteForm").addEventListener("submit", function (e) {
        e.preventDefault();
        let deleteForm = new FormData(this);
        const xhttp = new XMLHttpRequest();
        xhttp.addEventListener("readystatechange", function () {
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText);
                let data = JSON.parse(this.responseText);
                updateOptions(data);
            }
        });
        xhttp.open("POST", "json_output.php", true);
        xhttp.send(deleteForm);
    });
}

function updateOptions(data) {
    let empOptionList = document.getElementById("CodigoEmpleado");
    empOptionList.innerHTML = "";
    for (index = 0; index < data.length; index++) {
        let option = document.createElement("option");
        option.innerHTML = data[index]["Apellido1"] + " " + data[index]["Apellido2"] + ", " + data[index]["Nombre"];
        option.value = data[index]["CodigoEmpleado"];
        empOptionList.appendChild(option);
    }
}