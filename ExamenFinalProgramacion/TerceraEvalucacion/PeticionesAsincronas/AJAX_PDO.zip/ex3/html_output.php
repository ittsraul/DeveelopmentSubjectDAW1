<?php


$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

try {
    //Establece la conexión
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if (count($_POST) > 0) {
        $conn->beginTransaction();

        $stmt = $conn->prepare("DELETE FROM Empleados WHERE CodigoEmpleado = ?");
        $stmt->bindParam(1, $_POST["CodigoEmpleado"], PDO::PARAM_INT);

        $stmt->execute();
        echo "Se han borrado " . $stmt->rowCount() . " Filas";
        $conn->commit();
    }

    $sql = "SELECT CodigoEmpleado, Nombre, Apellido1, Apellido2 FROM Empleados ORDER BY Apellido1, Apellido2, Nombre";

    $empleadosDB = $conn->query($sql);
    $empleados = $empleadosDB->fetchAll(PDO::FETCH_ASSOC);

    $output = "";
    foreach ($empleados as $empleado) {
        $output .= "<option value='" . $empleado["CodigoEmpleado"] . "'>";
        $output .= $empleado["Apellido1"] . " ";
        $output .= $empleado["Apellido2"] . ", ";
        $output .= $empleado["Nombre"];
        $output .= "</option>";
    }
} catch (PDOException $e) {
    echo "<br>Se ha producido una excepción:" . $e->getMessage();
} finally {
    //cierra la conexión
    $conn = null;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <select name="CodigoEmpleado">
            <?= $output ?>
        </select>
        <br>
        <input type="submit" value="Borrar">
    </form>
</body>
</html>