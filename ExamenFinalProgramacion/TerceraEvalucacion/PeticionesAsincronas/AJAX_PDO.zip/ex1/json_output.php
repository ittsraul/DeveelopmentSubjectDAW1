<?php

//Server Side Rendering

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT * FROM Clientes WHERE CodigoCliente = 10";
$result = $conn->query($sql);
$arrayResult = $result->fetch(PDO::FETCH_ASSOC);
$jsonResult = json_encode($arrayResult);
echo $jsonResult;
//cierra la conexión
$conn = null;
