<?php

//Server Side Rendering

$servername = "127.0.0.1";
$username = "root";
$password = "";
$db = "jardineria";

//Establece la conexión
$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);

$sql = "SELECT * FROM Clientes WHERE CodigoCliente = 10";
$result = $conn->query($sql);


if ($result->rowCount() > 0) {
  echo "<table border='1'>";
  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    foreach ($row as $key => $value) {
      echo "<tr><td>$key</td><td>$value</td></tr>";
    }
  }
  echo "</table>";
} else {
  echo "0 results";
}

//cierra la conexión
$conn = null;
