<?php

class Cartera
{
    private $clients = [];
    private $conn;
    public function __construct()
    {
        $servername = "127.0.0.1";
        $username = "root";
        $password = "";
        $db = "daw_advertising";

        //Establece la conexión
        try {
            $this->conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Falló la conexión: ' . $e->getMessage();
        }
    }

    public function __destruct()
    {
        //cierra la conexión
        $this->conn = null;
    }

    public function import($fichero)
    {
        try {
            $this->conn->beginTransaction();
            $sqlDelete = "DELETE FROM empresa";
            $rowsDeleted = $this->conn->exec($sqlDelete);

            echo "Filas borradas " . $rowsDeleted . "<br>";

            $stmtInsert = $this->conn->prepare("INSERT INTO empresa VALUES(?,?,?,?,?,?)");
            $stmtInsert->bindParam(1, $id, PDO::PARAM_STR);
            $stmtInsert->bindParam(2, $company, PDO::PARAM_STR);
            $stmtInsert->bindParam(3, $investment, PDO::PARAM_STR);
            $stmtInsert->bindParam(4, $date, PDO::PARAM_STR);
            $stmtInsert->bindParam(5, $active, PDO::PARAM_BOOL);
            $stmtInsert->bindParam(6, $info, PDO::PARAM_STR);

            $gestor = fopen($fichero, "r");
            $linesCount = 0;
            while (($element = fgetcsv($gestor)) !== false) {
                $id = $element[0];
                $company = $element[1];
                $investment = $element[2];
                $date = $element[3];
                $active = ($element[4] == 'True') ? true : false;
                $info = $element[5];
                $stmtInsert->execute();
                $linesCount++;
            }
            fclose($gestor);
            echo "Filas importadas con éxito " . $linesCount . "<br>";
            $this->conn->commit();
        } catch (Exception | PDOException $e) {
            echo 'Falló la importación: ' . $e->getMessage();
            $stmtInsert->debugDumpParams();
        }
    }

    public function getAll()
    {
        try {
            $sqlAll = "SELECT * FROM empresa";
            $rowsAll = $this->conn->query($sqlAll);
            while ($empresa = $rowsAll->fetch(PDO::FETCH_ASSOC)) {
                array_push($this->clients, new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                ));
            }
        } catch (PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        //var_dump($this->clients);
    }

    public function drawList()
    {
        $output = "";
        foreach ($this->clients as $client) {
            $output .= "<tr>";
            $output .= "    <td>" . $client->getId() . "</td>";
            $output .= "    <td><a href='detalle.php?id=" . $client->getId() . "'>" . $client->getCompany() . "</a></td>";
            $output .= "    <td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td>";
            $output .= "    <td>" . date("F d, Y", strtotime($client->getDate())) . "</td>";
            $output .= "    <td>";
            $output .= ($client->getActive()) ?
                "<img src='img/img05.gif'>" :
                "<img src='img/img06.gif'>";
            $output .= "    </td>";

            $output .= "</tr>";
        }
        return $output;
    }

    function getClient($id)
    {
        try {
            $stmtClient = $this->conn->prepare("SELECT * FROM empresa WHERE id = :id");
            $stmtClient->bindParam(':id', $id, PDO::PARAM_STR);
            if ($stmtClient->execute() && $stmtClient->rowCount() > 0) {
                $empresa = $stmtClient->fetch(PDO::FETCH_ASSOC);
                return new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                );
            }
        } catch (Exception | PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        return new Empresa(null, null, null, null, null, null);
    }

    public function drawDetail($id)
    {
        $client = $this->getClient($id);
        $output = "";
        $output .= "<tr><th>Id</th><td>" . $client->getId() . "</td></tr>";
        $output .= "<tr><th>Company</th><td>" . $client->getCompany() . "</td></tr>";
        $output .= "<tr><th>Investment</th><td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td></tr>";
        $output .= "<tr><th>Date</th><td>" . date("F d, Y", strtotime($client->getDate())) . "</td></tr>";
        $output .= "<tr><th>Active</th><td>";
        $output .= ($client->getActive()) ?
            "<img src='img/img05.gif'>" :
            "<img src='img/img06.gif'>";
        $output .= "</td></tr>";
        $output .= "<tr><th>Info</th><td>" . $client->getInfo() . "</td></tr>";

        return $output;
    }
}
