DROP TABLE IF EXISTS `bolsa`;

CREATE TABLE `bolsa` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `company` varchar(255),
  `NASDAQ` TINYINT(1) default NULL,
  `NIKKEI` TINYINT(1) default NULL,
  `IBEX` TINYINT(1) default NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=1;

INSERT INTO `bolsa` (`company`,`NASDAQ`,`NIKKEI`,`IBEX`)
VALUES
  ("Amet Lorem Semper Foundation",False,True,True),
  ("Luctus Ut Inc.",False,True,True),
  ("Lacinia Incorporated",True,False,False),
  ("Nibh Vulputate LLC",True,True,True),
  ("Nec Tempus Limited",True,False,False),
  ("Praesent Foundation",False,True,True),
  ("Enim Sit Corporation",True,False,True),
  ("Aliquam Ornare Institute",False,True,True),
  ("Non LLP",True,True,False),
  ("Parturient Associates",False,False,True);
INSERT INTO `bolsa` (`company`,`NASDAQ`,`NIKKEI`,`IBEX`)
VALUES
  ("Ut Mi Incorporated",True,True,False),
  ("Non Massa Consulting",True,False,False),
  ("Consequat Foundation",False,True,False),
  ("Cubilia Curae Corp.",True,False,False),
  ("Nisi Industries",True,True,False),
  ("Tristique Senectus Et Corp.",False,False,True),
  ("Mi Duis PC",False,False,True),
  ("Elementum Sem Institute",False,False,True),
  ("Nec Tempus Limited",True,False,False),
  ("Litora Torquent LLP",False,False,True);
