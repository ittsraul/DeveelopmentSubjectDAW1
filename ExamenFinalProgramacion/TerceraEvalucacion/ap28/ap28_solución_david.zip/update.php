<?php

require_once "autoload.php";

$bolsa = new Bolsa();

$bolsa->update($_GET["id"], $_GET["field"], $_GET["value"]);
