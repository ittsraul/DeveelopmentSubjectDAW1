document.addEventListener("DOMContentLoaded", main);

function main() {
    let formulario = document.getElementById("formFilter");
    formulario.addEventListener("submit", function (e) {
        e.preventDefault();
        loadData(this);
    });
    loadData(formulario);
}
function loadData(form) {
    let formFilter = new FormData(form);
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            let data = JSON.parse(this.responseText);
            drawList(data);
        }
    });
    xhttp.open("POST", "list.php", true);
    xhttp.send(formFilter);
}
function drawList(data) {
    let companyRows = document.getElementById("companyRows");
    companyRows.innerHTML = "";
    for (let index = 0; index < data.length; index++) {
        let row = document.createElement("tr");
        let id = data[index]["id"];
        for (field in data[index]) {
            let col = document.createElement("td");
            switch (field) {
                case "id":
                    col.innerHTML = id;
                    break;
                case "company":
                    col.innerHTML = data[index][field];
                    break;
                default:
                    let fieldName = field;
                    let checkSlider = document.createElement("label");
                    checkSlider.className = "switch";
                    let inputCheckSlider = document.createElement("input");
                    inputCheckSlider.type = "checkbox";
                    inputCheckSlider.checked = data[index][field];
                    inputCheckSlider.addEventListener("click", function () {
                        updateAction(id, fieldName, this.checked);
                    });
                    checkSlider.appendChild(inputCheckSlider);
                    let spanCheckSlider = document.createElement("span");
                    spanCheckSlider.className = "slider round";
                    checkSlider.appendChild(spanCheckSlider);
                    col.appendChild(checkSlider);
            }
            row.appendChild(col);
        }
        companyRows.appendChild(row);
    }
}


function updateAction(id, field, value) {
    const xhttp = new XMLHttpRequest();
    xhttp.addEventListener("readystatechange", function () {
        if (this.readyState == 4 && this.status == 200) {
            //console.log((this.responseText));
            //loadData();
        }
    });
    value = (value) ? 1 : 0;
    let queryString = "update.php?id=" + id + "&field=" + field + "&value=" + value;
    console.log(queryString);
    xhttp.open("GET", queryString, true);
    xhttp.send();
} 
