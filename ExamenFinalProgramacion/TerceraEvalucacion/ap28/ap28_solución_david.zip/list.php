<?php

require_once "autoload.php";

$bolsa = new Bolsa();

if (count($_POST) > 0) echo json_encode($bolsa->getAll($_POST["indiceBursatil"]));
