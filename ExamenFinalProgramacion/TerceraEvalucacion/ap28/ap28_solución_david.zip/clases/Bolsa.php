<?php

class Bolsa extends Conexion
{
    public function getAll($criteria)
    {
        try {
            $sqlAll = "SELECT * FROM bolsa";
            if ($criteria != "") $sqlAll .= " WHERE $criteria = true";
            
            $rowsAll = $this->conn->query($sqlAll);
            return $rowsAll->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
    }

    public function update($id, $field, $value)
    {
        try {


            $stmtUpdate = $this->conn->prepare("UPDATE bolsa SET $field = ? WHERE id = ?");

            $stmtUpdate->bindParam(1, $value, PDO::PARAM_BOOL);
            $stmtUpdate->bindParam(2, $id, PDO::PARAM_STR);

            $stmtUpdate->execute();
            return $stmtUpdate->rowCount();
        } catch (Exception | PDOException $e) {
            echo 'Falló la actualización: ' . $e->getMessage();
        }
    }
}
