<?php

class Cartera extends Conexion
{
    private $clients = [];
    
    public function import($fichero)
    {
        try {
            $this->conn->beginTransaction();
            $sqlDelete = "DELETE FROM empresa";
            $rowsDeleted = $this->conn->exec($sqlDelete);

            echo "Filas borradas " . $rowsDeleted . "<br>";

            $stmtInsert = $this->conn->prepare("INSERT INTO empresa VALUES(?,?,?,?,?,?)");
            $stmtInsert->bindParam(1, $id, PDO::PARAM_STR);
            $stmtInsert->bindParam(2, $company, PDO::PARAM_STR);
            $stmtInsert->bindParam(3, $investment, PDO::PARAM_STR);
            $stmtInsert->bindParam(4, $date, PDO::PARAM_STR);
            $stmtInsert->bindParam(5, $active, PDO::PARAM_BOOL);
            $stmtInsert->bindParam(6, $info, PDO::PARAM_STR);

            $gestor = fopen($fichero, "r");
            $linesCount = 0;
            while (($element = fgetcsv($gestor)) !== false) {
                $id = $element[0];
                $company = $element[1];
                $investment = $element[2];
                $date = $element[3];
                $active = ($element[4] == 'True') ? true : false;
                /* if($element[4] == 'True') {
                    $active =  true;
                }else{
                    $active = false;
                } */
                $info = $element[5];
                $stmtInsert->execute();
                $linesCount++;
            }
            fclose($gestor);
            echo "Filas importadas con éxito " . $linesCount . "<br>";
            $this->conn->commit();
        } catch (Exception | PDOException $e) {
            echo 'Falló la importación: ' . $e->getMessage();
            $stmtInsert->debugDumpParams();
        }
    }

    public function getAll()
    {
        try {
            $sqlAll = "SELECT * FROM empresa ORDER BY `date` DESC";
            $rowsAll = $this->conn->query($sqlAll);
            while ($empresa = $rowsAll->fetch(PDO::FETCH_ASSOC)) {
                array_push($this->clients, new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                ));
            }
        } catch (PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        //var_dump($this->clients);
    }

    public function drawList()
    {
        $output = "";
        foreach ($this->clients as $client) {
            $output .= "<tr>";
            $output .= "    <td>" . $client->getId() . "</td>";
            $output .= "    <td><a href='detalle.php?id=" . $client->getId() . "'>" . $client->getCompany() . "</a></td>";
            $output .= "    <td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td>";
            $output .= "    <td>" . date("F d, Y", strtotime($client->getDate())) . "</td>";
            $output .= "    <td>";
            $output .= ($client->getActive()) ?
                "<img src='img/img05.gif'>" :
                "<img src='img/img06.gif'>";
            $output .= "    </td>";
            $output .=     "<td><a href='delete.php?id=" . $client->getId() . "'><img src='img/del_icon.png' width='25'></a></td>";
            $output .=     "<td><a href='edit.php?id=" . $client->getId() . "'><img src='img/edit_icon.png' width='25'></a></td>";
            $output .= "</tr>";
        }
        return $output;
    }

    function getClient($id)
    {
        try {
            /*
            $sql = "SELECT * FROM empresa WHERE id = '$id'";
            $this->conn->query($sql); 
            */
            $stmtClient = $this->conn->prepare("SELECT * FROM empresa WHERE id = :id");
            $stmtClient->bindParam(':id', $id, PDO::PARAM_STR);
            if ($stmtClient->execute() && $stmtClient->rowCount() > 0) {
                $empresa = $stmtClient->fetch(PDO::FETCH_ASSOC);
                return new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                );
            }
        } catch (Exception | PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        //return new Empresa(null, null, null, null, null, null);
        return false;
    }

    public function drawDetail($id)
    {
        $client = $this->getClient($id);
        if ($client === false) {
            echo "no se encuentra...";
        } else {
            $output = "";
            $output .= "<tr><th>Id</th><td>" . $client->getId() . "</td></tr>";
            $output .= "<tr><th>Company</th><td>" . $client->getCompany() . "</td></tr>";
            $output .= "<tr><th>Investment</th><td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td></tr>";
            $output .= "<tr><th>Date</th><td>" . date("F d, Y", strtotime($client->getDate())) . "</td></tr>";
            $output .= "<tr><th>Active</th><td>";
            $output .= ($client->getActive()) ?
                "<img src='img/img05.gif'>" :
                "<img src='img/img06.gif'>";
            $output .= "</td></tr>";
            $output .= "<tr><th>Info</th><td>" . $client->getInfo() . "</td></tr>";

            return $output;
        }
    }

    public function delete($id)
    {
        try {
            $stmtDelete = $this->conn->prepare("DELETE FROM empresa WHERE id = :id");
            $stmtDelete->bindParam(':id', $id, PDO::PARAM_STR);
            $stmtDelete->execute();
            return $stmtDelete->rowCount();
        } catch (Exception | PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
    }

    public function new($data)
    {
        try {
            $stmtInsert = $this->conn->prepare("INSERT INTO empresa VALUES(?,?,?,?,?,?)");
            $stmtInsert->bindParam(1, $id, PDO::PARAM_STR);
            $stmtInsert->bindParam(2, $company, PDO::PARAM_STR);
            $stmtInsert->bindParam(3, $investment, PDO::PARAM_STR);
            $stmtInsert->bindParam(4, $date, PDO::PARAM_STR);
            $stmtInsert->bindParam(5, $active, PDO::PARAM_BOOL);
            $stmtInsert->bindParam(6, $info, PDO::PARAM_STR);

            $id = $data["id"];
            $company = $data["company"];
            $investment = $data["investment"];
            $date = $data["date"];
            $active = (isset($data["active"])) ? true : false;
            $info = $data["info"];

            $stmtInsert->execute();
            return $stmtInsert->rowCount();

        } catch (Exception | PDOException $e) {
            echo 'Falló la inserción: ' . $e->getMessage();
        }
    }

    public function update($data)
    {
        try {
            $stmtUpdate = $this->conn->prepare("UPDATE empresa SET company = ?, investment = ?, `date` = ?, active = ?, info = ? WHERE id = ?");
            
            $stmtUpdate->bindParam(1, $company, PDO::PARAM_STR);
            $stmtUpdate->bindParam(2, $investment, PDO::PARAM_STR);
            $stmtUpdate->bindParam(3, $date, PDO::PARAM_STR);
            $stmtUpdate->bindParam(4, $active, PDO::PARAM_BOOL);
            $stmtUpdate->bindParam(5, $info, PDO::PARAM_STR);
            $stmtUpdate->bindParam(6, $id, PDO::PARAM_STR);

            $id = $data["id"];
            $company = $data["company"];
            $investment = $data["investment"];
            $date = $data["date"];
            $active = (isset($data["active"])) ? true : false;
            $info = $data["info"];

            $stmtUpdate->execute();
            return $stmtUpdate->rowCount();
            
        } catch (Exception | PDOException $e) {
            echo 'Falló la actualización: ' . $e->getMessage();
        }
    }
}
