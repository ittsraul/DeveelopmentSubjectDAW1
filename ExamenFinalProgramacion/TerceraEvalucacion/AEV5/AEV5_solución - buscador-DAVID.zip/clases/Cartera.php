<?php

class Cartera extends Conexion
{
    private $clients = [];
    private $pag;
    private $order;
    private $filter;

    public function  __construct()
    {
        $this->setPag();
        $this->setOrder();
        $this->setFilter();
        
        parent::__construct();
    }

    public function import($fichero)
    {
        try {
            $this->conn->beginTransaction();
            $sqlDelete = "DELETE FROM empresa";
            $rowsDeleted = $this->conn->exec($sqlDelete);

            echo "Filas borradas " . $rowsDeleted . "<br>";

            $stmtInsert = $this->conn->prepare("INSERT INTO empresa VALUES(?,?,?,?,?,?)");
            $stmtInsert->bindParam(1, $id, PDO::PARAM_STR);
            $stmtInsert->bindParam(2, $company, PDO::PARAM_STR);
            $stmtInsert->bindParam(3, $investment, PDO::PARAM_STR);
            $stmtInsert->bindParam(4, $date, PDO::PARAM_STR);
            $stmtInsert->bindParam(5, $active, PDO::PARAM_BOOL);
            $stmtInsert->bindParam(6, $info, PDO::PARAM_STR);

            $gestor = fopen($fichero, "r");
            $linesCount = 0;
            while (($element = fgetcsv($gestor)) !== false) {
                $id = $element[0];
                $company = $element[1];
                $investment = $element[2];
                $date = $element[3];
                $active = ($element[4] == 'True') ? true : false;
                /* if($element[4] == 'True') {
                    $active =  true;
                }else{
                    $active = false;
                } */
                $info = $element[5];
                $stmtInsert->execute();
                $linesCount++;
            }
            fclose($gestor);
            echo "Filas importadas con éxito " . $linesCount . "<br>";
            $this->conn->commit();
        } catch (Exception | PDOException $e) {
            echo 'Falló la importación: ' . $e->getMessage();
            $stmtInsert->debugDumpParams();
        }
    }

    public function getAll()
    {
        try {
            $limiteInferior = ($this->pag - 1) * $this->itemsPag;
            $sqlAll = "SELECT * FROM empresa  WHERE company LIKE '%" . $this->filter . "%' ORDER BY `date` " . $this->order . " LIMIT $limiteInferior, " . $this->itemsPag;
            $rowsAll = $this->conn->query($sqlAll);
            while ($empresa = $rowsAll->fetch(PDO::FETCH_ASSOC)) {
                array_push($this->clients, new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                ));
            }
            $this->rowCount = $rowsAll->rowCount();
        } catch (PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        //var_dump($this->clients);
    }

    public function drawList()
    {

        $output = "";
        foreach ($this->clients as $client) {
            $output .= "<tr>";
            $output .= "    <td>" . $client->getId() . "</td>";
            $output .= "    <td><a href='detalle.php?id=" . $client->getId() . "'>" . $client->getCompany() . "</a></td>";
            $output .= "    <td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td>";
            $output .= "    <td>" . date("F d, Y", strtotime($client->getDate())) . "</td>";
            $output .= "    <td>";
            $output .= ($client->getActive()) ?
                "<img src='img/img05.gif'>" :
                "<img src='img/img06.gif'>";
            $output .= "    </td>";
            $output .=     "<td><a href='delete.php?id=" . $client->getId() . "'><img src='img/del_icon.png' width='25'></a></td>";
            $output .=     "<td><a href='edit.php?id=" . $client->getId() . "'><img src='img/edit_icon.png' width='25'></a></td>";
            $output .= "</tr>";
        }
        return $output;
    }

    function getClient($id)
    {
        try {
            /*
            $sql = "SELECT * FROM empresa WHERE id = '$id'";
            $this->conn->query($sql); 
            */
            $stmtClient = $this->conn->prepare("SELECT * FROM empresa WHERE id = :id");
            $stmtClient->bindParam(':id', $id, PDO::PARAM_STR);
            if ($stmtClient->execute() && $stmtClient->rowCount() > 0) {
                $empresa = $stmtClient->fetch(PDO::FETCH_ASSOC);
                return new Empresa(
                    $empresa["id"],
                    $empresa["company"],
                    floatval($empresa["investment"]),
                    $empresa["date"],
                    boolval($empresa["active"]),
                    $empresa["info"]
                );
            }
        } catch (Exception | PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
        //return new Empresa(null, null, null, null, null, null);
        return false;
    }

    public function drawDetail($id)
    {
        $client = $this->getClient($id);
        if ($client === false) {
            echo "no se encuentra...";
        } else {
            $output = "";
            $output .= "<tr><th>Id</th><td>" . $client->getId() . "</td></tr>";
            $output .= "<tr><th>Company</th><td>" . $client->getCompany() . "</td></tr>";
            $output .= "<tr><th>Investment</th><td>" . number_format(intval($client->getInvestment()), 2, "'", ".") . " €</td></tr>";
            $output .= "<tr><th>Date</th><td>" . date("F d, Y", strtotime($client->getDate())) . "</td></tr>";
            $output .= "<tr><th>Active</th><td>";
            $output .= ($client->getActive()) ?
                "<img src='img/img05.gif'>" :
                "<img src='img/img06.gif'>";
            $output .= "</td></tr>";
            $output .= "<tr><th>Info</th><td>" . $client->getInfo() . "</td></tr>";

            return $output;
        }
    }

    public function delete($id)
    {
        try {
            $stmtDelete = $this->conn->prepare("DELETE FROM empresa WHERE id = :id");
            $stmtDelete->bindParam(':id', $id, PDO::PARAM_STR);
            $stmtDelete->execute();
            return $stmtDelete->rowCount();
        } catch (Exception | PDOException $e) {
            echo 'Falló la consulta: ' . $e->getMessage();
        }
    }

    public function new($data)
    {
        try {
            $stmtInsert = $this->conn->prepare("INSERT INTO empresa VALUES(?,?,?,?,?,?)");
            $stmtInsert->bindParam(1, $id, PDO::PARAM_STR);
            $stmtInsert->bindParam(2, $company, PDO::PARAM_STR);
            $stmtInsert->bindParam(3, $investment, PDO::PARAM_STR);
            $stmtInsert->bindParam(4, $date, PDO::PARAM_STR);
            $stmtInsert->bindParam(5, $active, PDO::PARAM_BOOL);
            $stmtInsert->bindParam(6, $info, PDO::PARAM_STR);

            $id = $data["id"];
            $company = $data["company"];
            $investment = $data["investment"];
            $date = $data["date"];
            $active = (isset($data["active"])) ? true : false;
            $info = $data["info"];

            $stmtInsert->execute();
            return $stmtInsert->rowCount();
        } catch (Exception | PDOException $e) {
            echo 'Falló la inserción: ' . $e->getMessage();
        }
    }

    public function update($data)
    {
        try {
            $stmtUpdate = $this->conn->prepare("UPDATE empresa SET company = ?, investment = ?, `date` = ?, active = ?, info = ? WHERE id = ?");

            $stmtUpdate->bindParam(1, $company, PDO::PARAM_STR);
            $stmtUpdate->bindParam(2, $investment, PDO::PARAM_STR);
            $stmtUpdate->bindParam(3, $date, PDO::PARAM_STR);
            $stmtUpdate->bindParam(4, $active, PDO::PARAM_BOOL);
            $stmtUpdate->bindParam(5, $info, PDO::PARAM_STR);
            $stmtUpdate->bindParam(6, $id, PDO::PARAM_STR);

            $id = $data["id"];
            $company = $data["company"];
            $investment = $data["investment"];
            $date = $data["date"];
            $active = (isset($data["active"])) ? true : false;
            $info = $data["info"];

            $stmtUpdate->execute();
            return $stmtUpdate->rowCount();
        } catch (Exception | PDOException $e) {
            echo 'Falló la actualización: ' . $e->getMessage();
        }
    }
    public function navBar()
    {
        /* $sql = "SELECT COUNT(*) FROM empresa";
        $result = $this->conn->query($sql);
        $resultTotal = $result->fetch(PDO::FETCH_NUM);
        $total = $resultTotal[0]; */

        /* $sql = "SELECT COUNT(*) AS total FROM empresa";
        $result = $this->conn->query($sql);
        $resultTotal = $result->fetch(PDO::FETCH_ASSOC);
        $total = $resultTotal["total"]; */

        $sql = "SELECT COUNT(*) FROM empresa  WHERE company LIKE '%" . $this->filter . "%'";
        $result = $this->conn->query($sql)->fetch(PDO::FETCH_NUM);
        $total = array_shift($result);

        $totalButtons = ceil($total / $this->itemsPag);
        $output = [];
        for ($i = 1; $i <= $totalButtons; $i++) {
            if ($this->pag != $i) {
                array_push($output, "<a href='listado.php?pag=$i'>$i</a>");
            } else {
                array_push($output, $i);
            }
        }
        return implode(" - ", $output);
    }

    private function setPag($defaultPage = null)
    {
        /* $this->setCurrentState("pag", "pag", 1); */
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (!is_null($defaultPage)) {
            $this->pag = $defaultPage;
        } elseif (isset($_GET["pag"])) {
            $this->pag = $_GET["pag"];
        } elseif (isset($_SESSION["pag"])) {
            $this->pag = $_SESSION["pag"];
        } else {
            $this->pag = 1;
        }
        $_SESSION["pag"] = $this->pag;
    }

    private function setOrder()
    {
        
        /* $this->setCurrentState("order", "order", "desc");
        $this->setCurrentState("pag", "pag", 1, 1); */
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (isset($_GET["order"])) {
            $this->order = $_GET["order"];
            $this->setPag(1);
        } elseif (isset($_SESSION["order"])) {
            $this->order = $_SESSION["order"];
        } else {
            $this->order = "DESC";
        }
        $_SESSION["order"] = $this->order;
    }

    private function setFilter()
    {
        /* $this->setCurrentState("company", "filter", "");
        $this->setCurrentState("pag", "pag", 1, 1); */

        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (isset($_POST["company"])) {
            $this->filter = $_POST["company"];
            $this->setPag(1);
        } elseif (isset($_SESSION["company"])) {
            $this->filter = $_SESSION["company"];
        } else {
            $this->filter = "";
        }
        $_SESSION["company"] = $this->filter;
    }

    private function setCurrentState($param, $attrib, $default, $value = null)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (!is_null($value)) {
            $this->pag = $value;
        } elseif (isset($_REQUEST[$param])) {
            $this->$attrib = $_REQUEST[$param];
        } elseif (isset($_SESSION[$param])) {
            $this->$attrib = $_SESSION[$param];
        } else {
            $this->$attrib = $default;
        }
        $_SESSION[$param] = $this->$attrib;
    }

    public function getFilter()
    {
        return $this->filter;
    }
}
